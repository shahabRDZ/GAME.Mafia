# ShowShung Mafia Theme — Prompt for Claude

Use the files in this package to redesign my web app UI with a unified dark gothic mafia theme.

Project: ShowShung — online Mafia game
Visual direction:
- Dark cinematic mafia / noir / gothic
- Skeleton cards, gold borders, dark red accents, smoky atmosphere
- Premium game UI, not generic dashboard UI
- Persian RTL support is required

Use:
- `theme.css` as the global design system
- `components.css` for reusable UI elements
- `layout-example.html` as the visual reference
- `ui-tokens.json` as design tokens

Apply this theme to all pages:
- home
- scenario selection
- role cards
- events
- login/register
- modals
- buttons
- bottom navigation
- panels/cards/forms

Requirements:
1. Keep the UI responsive.
2. Use RTL-friendly spacing.
3. Replace colorful emoji-style icons with custom dark/gold gothic icons where possible.
4. Use transparent dark panels over the background.
5. Buttons must use red/gold mafia styling.
6. Cards must feel like collectible mafia game cards.
7. Do not make the UI too bright.
8. Preserve usability and readability.
9. Use Persian typography with Vazirmatn/Peyda-style fonts.
10. Add hover/focus states and subtle glow animations.

Goal:
Make the entire site feel like one premium cinematic mafia game interface.
